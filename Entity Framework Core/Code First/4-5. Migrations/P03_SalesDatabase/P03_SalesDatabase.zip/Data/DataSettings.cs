﻿namespace P03_SalesDatabase.Data
{
    public class DataSettings
    {
        public const string ConnectionString = @"Server=DESKTOP-P3QQLJA\SQLEXPRESS;Database=SalesDb;Integrated Security = true";
    }
}
