﻿namespace P01_HospitalDatabase.Data
{
    public class DataSettings
    {
        public const string DefaultConnection = @"Server=DESKTOP-P3QQLJA\SQLEXPRESS;Database=HospitalDb;Integrated Security=true";
    }
}
